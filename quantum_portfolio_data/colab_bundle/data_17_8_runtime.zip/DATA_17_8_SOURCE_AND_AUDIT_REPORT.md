# Data 17/8 - Báo cáo nguồn và kiểm toán dữ liệu

**Ngày chốt phiên bản:** 17/08/2026  
**Giai đoạn nghiên cứu:** 2020-01-01 đến 2025-12-31  
**Trạng thái confirmatory:** `blocked`

## Phạm vi

Data 17/8 kế thừa duy nhất security master có lịch sử niêm yết/hủy niêm yết chính thức; panel giá được dựng lại độc lập. Giá OHLC và giá trị giao dịch gốc lấy từ CafeF, chuỗi điều chỉnh lấy từ KBS và chỉ được chấp nhận khi lợi nhuận điều chỉnh khớp chéo giữa hai nguồn. Những mã có corporate action trọng yếu chưa xác minh bị loại toàn bộ trước khi chạy mô hình, không bị loại dựa trên kết quả sinh lợi.

Kho tài liệu lưu toàn bộ metadata BCTC/BCTN giai đoạn 2020–2025 cho security master và tải các binary chuẩn tắc theo năm. HOSE là nguồn công bố chính thức; Vietstock chỉ giữ vai trò kho tổng hợp bổ sung. Mọi đặc trưng tài chính chỉ được sử dụng sau `available_at` và phải kèm bằng chứng trang của tài liệu nguồn.

## Kết quả kiểm toán

| Kiểm tra | Kết quả | Chi tiết |
|---|---:|---|
| `price_panel` | PASS | rows=157826, tickers=120, start=2020-01-02, end=2025-12-31 |
| `verified_price_adjustment` | PASS |  |
| `cafef_kbs_price_crosscheck` | PASS | verified_tickers=120, rows=157826 |
| `official_total_return_benchmark` | PASS | rows=1499, benchmark=['VNALLSHARETRI'], expected_trading_dates=1499, missing_trading_dates=0, unexpected_dates=0 |
| `financial_statements_pit` | FAIL | reason=missing |
| `historical_sector_pit` | FAIL | reason=missing |
| `company_document_repository` | FAIL | master_tickers=394, bctc_tickers=394, bctn_tickers=394, canonical_binaries_required=3094, canonical_binaries_downloaded=3085 |
| `corporate_action_ledger` | PASS | rows=2653, verified=1774, unresolved_material_all_master_tickers=879, unresolved_material_in_complete_case_panel=0, panel_tickers=120 |

## Blocker còn lại

- `company_document_repository_incomplete`

## Quy tắc diễn giải

Benchmark được giữ đúng tên `VNALLSHARETRI`; đây không phải chuỗi VN-Index TRI. Bản GICS hiện tại của HOSE chỉ là snapshot 2026 và không được hồi tố; nếu không thu được ấn phẩm phân ngành lịch sử thì ràng buộc ngành được vô hiệu hóa và công khai trong diagnostics. Số liệu OCR không vượt qua kiểm tra đơn vị, thời điểm công bố và cân đối sẽ không được đưa vào mô hình.
